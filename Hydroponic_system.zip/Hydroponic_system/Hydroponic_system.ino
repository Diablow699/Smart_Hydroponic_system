/*
 * ============================================================================
 * PROJECT:     ESP32 IoT Hydroponic Environmental Monitoring & Control System
 *              for Tipburn Mitigation in Lettuce
 * AUTHOR:      [Your Name]
 * INSTITUTION: [Your University / Research Lab]
 * VERSION:     4.0.0 — Full Alert System Integration
 * DATE:        2025
 * ============================================================================
 *
 * CHANGE LOG v4.0.0:
 *   - Added priority-based alert system (setAlert / clearAlert)
 *   - All 15 V10 alert messages integrated into correct functions
 *   - Alert priority levels: 1=OK, 2=WARN, 3=ALERT, 4=EMERGENCY
 *   - Higher priority alerts cannot be overwritten by lower ones
 *   - currentAlertPriority tracker added to Section 3
 *   - DHT22 failure now forces mister and exhaust OFF safely
 *   - All systemAlert = "..." replaced with setAlert() calls
 *   - All clearAlert() calls added when conditions resolve
 * ============================================================================
 */


/* ============================================================================
 * SECTION 1: REQUIRED LIBRARIES
 * ============================================================================
 */
#define BLYNK_TEMPLATE_ID   "TMPL6IkGktaE7"
#define BLYNK_TEMPLATE_NAME "Hydroponic"
#define BLYNK_AUTH_TOKEN    "Your Auth Token"

#include <WiFi.h>
#include <BlynkSimpleEsp32.h>
#include <DHT.h>
#include <Wire.h>
#include <RTClib.h>
#include <Preferences.h>


/* ============================================================================
 * SECTION 2: GPIO DEFINITIONS
 * ============================================================================
 */

// --- SENSOR PINS ---
#define PIN_DHT22           4
#define PIN_EC_SENSOR       34
#define PIN_WATER_SENSOR    35
#define PIN_ULTRA_SONIC_SENSOR    27

// --- ACTUATOR / RELAY PINS (ALL ACTIVE LOW) ---
#define PIN_RELAY_DOSING    18   // Peristaltic dosing pump  — EC too LOW
#define PIN_RELAY_NFT_PUMP  19   // NFT circulation pump     — timed cycle
#define PIN_RELAY_REFILL    23   // Diaphragm refill pump    — EC too HIGH or water low
#define PIN_RELAY_LIGHTS    5    // LED grow lights          — RTC schedule
#define PIN_RELAY_MISTER    25   // Misting nozzle relay     — RH too LOW
#define PIN_RELAY_EXHAUST   26   // Exhaust fan relay        — RH too HIGH

// --- DHT SENSOR TYPE ---
#define DHT_TYPE            DHT22

// --- RELAY LOGIC (Active LOW — relay energizes on LOW signal) ---
#define RELAY_ON            LOW
#define RELAY_OFF           HIGH


/* ============================================================================
 * SECTION 3: GLOBAL VARIABLES & CONFIGURATION CONSTANTS
 * ============================================================================
 */

// --- NETWORK CREDENTIALS ---
const char* WIFI_SSID     = "YOUR_WIFI_SSID";
const char* WIFI_PASSWORD = "YOUR_WIFI_PASSWORD";

// ---------------------------------------------------------------------------
// HUMIDITY CONTROL THRESHOLDS
// ---------------------------------------------------------------------------
float HUMIDITY_MIN        = 67.26;  // % RH — Mister activates below this
float HUMIDITY_MAX        = 69.72;  // % RH — Exhaust fan activates above this
float HUMIDITY_TARGET     = 68.49;  // % RH — Midpoint setpoint
float HUMIDITY_HYSTERESIS = 0.25;   // % RH — Dead-band at each boundary

// ---------------------------------------------------------------------------
// EC CONTROL THRESHOLDS
// ---------------------------------------------------------------------------
float EC_LOWER_THRESHOLD  = 1.2;    // dS/m — Dose nutrients below this
float EC_UPPER_THRESHOLD  = 2.0;    // dS/m — Add plain water above this
float EC_HYSTERESIS       = 0.05;   // dS/m — Dead-band at each boundary

// --- PHOTOPERIOD SCHEDULE ---
const int LIGHTS_ON_HOUR  = 18;
const int LIGHTS_ON_MIN   = 0;
const int LIGHTS_OFF_HOUR = 6;
const int LIGHTS_OFF_MIN  = 0;

// --- NFT CIRCULATION TIMER ---
const unsigned long NFT_ON_DURATION_MS  = 15UL * 60UL * 1000UL;
const unsigned long NFT_OFF_DURATION_MS = 15UL * 60UL * 1000UL;

// --- FAIL-SAFE TIMEOUT LIMITS ---
const unsigned long DOSING_PUMP_MAX_ON_MS = 30UL  * 1000UL;
const unsigned long REFILL_PUMP_MAX_ON_MS = 5UL   * 60UL * 1000UL;
const unsigned long NFT_PUMP_MAX_ON_MS    = 16UL  * 60UL * 1000UL;
const unsigned long MISTER_MAX_ON_MS      = 2UL   * 60UL * 1000UL;
const unsigned long EXHAUST_MAX_ON_MS     = 10UL  * 60UL * 1000UL;

// --- EC MOVING AVERAGE FILTER ---
const int EC_SAMPLE_COUNT = 10;
float     ecSampleBuffer[EC_SAMPLE_COUNT];
int       ecSampleIndex   = 0;
bool      ecBufferFilled  = false;

// --- EC CALIBRATION ---
const float EC_ADC_REF_VOLTAGE  = 3.3;
const float EC_ADC_RESOLUTION   = 4095.0;
const float EC_VOLTAGE_OFFSET   = 0.0;
const float EC_CONVERSION_COEFF = 0.64;

// --- LIVE SENSOR VALUES ---
float currentTemperature  = 0.0;
float currentHumidity     = 0.0;
float currentEC           = 0.0;
int   currentWaterLevel   = 0;
bool  floatSwitchLow      = false;

// --- ACTUATOR STATE FLAGS ---
bool stateNFTPump    = false;
bool stateDosingPump = false;
bool stateRefillPump = false;
bool stateLights     = false;
bool stateMister     = false;
bool stateExhaust    = false;

// --- MILLIS TIMERS ---
unsigned long lastBlynkUpdateTime = 0;
unsigned long lastDebugPrintTime  = 0;
unsigned long nftPumpStartTime    = 0;
unsigned long dosingPumpStartTime = 0;
unsigned long refillPumpStartTime = 0;
unsigned long misterStartTime     = 0;
unsigned long exhaustStartTime    = 0;

// --- POLLING INTERVALS ---
const unsigned long SENSOR_READ_INTERVAL_MS  = 2000;
const unsigned long BLYNK_UPDATE_INTERVAL_MS = 5000;
const unsigned long DEBUG_PRINT_INTERVAL_MS  = 3000;

// --- NFT STATE MACHINE ---
enum NFTPumpState { NFT_PUMP_ON, NFT_PUMP_OFF };
NFTPumpState nftPumpState = NFT_PUMP_OFF;

// --- RTC ---
DateTime currentDateTime;
char     rtcTimeString[20];

// ---------------------------------------------------------------------------
// SYSTEM ALERT — Priority-Based
// ---------------------------------------------------------------------------
// Priority Levels:
//   1 = SYSTEM OK   (lowest  — default normal state)
//   2 = WARN        (normal automated response — system handling it)
//   3 = ALERT       (sensor or actuator fault — needs attention)
//   4 = EMERGENCY   (highest — complete shutdown triggered)
//
// Higher priority alerts will NOT be overwritten by lower ones.
// Example: EMERGENCY (4) cannot be replaced by WARN (2).
// ---------------------------------------------------------------------------
String systemAlert          = "SYSTEM OK";  // Current alert message for V10
int    currentAlertPriority = 1;            // Current alert priority level

// --- OBJECT INSTANCES ---
DHT         dht(PIN_DHT22, DHT_TYPE);
RTC_DS3231  rtc;
Preferences preferences;

// --- FREERTOS ---
TaskHandle_t      sensorTaskHandle  = NULL;
TaskHandle_t      controlTaskHandle = NULL;
SemaphoreHandle_t sensorDataMutex;


/* ============================================================================
 * ALERT HELPER FUNCTIONS
 * ============================================================================
 * Place these BEFORE all other functions so every section can call them.
 * ============================================================================
 */

/**
 * @brief Sets the system alert message only if new priority is
 *        equal to or higher than the current active alert priority.
 *
 * This prevents a low-priority WARN from overwriting a critical
 * ALERT or EMERGENCY message that is still active.
 *
 * Priority scale:
 *   1 = SYSTEM OK
 *   2 = WARN
 *   3 = ALERT
 *   4 = EMERGENCY
 *
 * @param message   Text to display on Blynk V10
 * @param priority  Priority level of this alert
 */
void setAlert(String message, int priority) {
    if (priority >= currentAlertPriority) {
        systemAlert          = message;
        currentAlertPriority = priority;
        Serial.printf("[ALERT] Priority %d → %s\n", priority, message.c_str());
    } else {
        Serial.printf("[ALERT] Suppressed (priority %d < current %d): %s\n",
                      priority, currentAlertPriority, message.c_str());
    }
}

/**
 * @brief Clears the system alert back to SYSTEM OK.
 *        Only clears if the resolving condition matches or exceeds
 *        the current alert priority level.
 *
 * @param priority  Priority level of the condition that just resolved
 */
void clearAlert(int priority) {
    if (priority >= currentAlertPriority) {
        systemAlert          = "SYSTEM OK";
        currentAlertPriority = 1;
        Serial.println("[ALERT] Cleared → SYSTEM OK");
    }
}


/* ============================================================================
 * SECTION 4: SENSOR READING FUNCTIONS
 * ============================================================================
 */

/**
 * @brief Reads temperature and humidity from DHT22.
 *
 * ALERT INTEGRATION:
 *   - Sets ALERT priority 3 if DHT22 returns NaN (sensor disconnected)
 *   - Forces mister and exhaust OFF on failure (unknown RH state — safety)
 *   - Clears ALERT priority 3 if reading recovers successfully
 */
void readDHT22() {
    float temp = dht.readTemperature();
    float hum  = dht.readHumidity();

    // -----------------------------------------------------------------------
    // ALERT: DHT22 Read Failure
    // Trigger: isnan() means sensor returned invalid data
    // Action:  Force mister and exhaust OFF — RH unknown
    // -----------------------------------------------------------------------
    if (isnan(temp) || isnan(hum)) {
        Serial.println("[DHT22][ERROR] Read failed — sensor may be disconnected!");

        // Set ALERT priority 3
        setAlert("ALERT: DHT22 Read Failure", 3);

        // Safety: unknown RH — force humidity actuators OFF
        if (stateMister) {
            digitalWrite(PIN_RELAY_MISTER, RELAY_OFF);
            stateMister = false;
            Serial.println("[DHT22][SAFETY] Mister forced OFF — RH unknown.");
        }
        if (stateExhaust) {
            digitalWrite(PIN_RELAY_EXHAUST, RELAY_OFF);
            stateExhaust = false;
            Serial.println("[DHT22][SAFETY] Exhaust forced OFF — RH unknown.");
        }
        return;  // Keep previous valid values — do not update globals
    }

    if (temp < 0.0 || temp > 60.0) {
        Serial.printf("[DHT22][WARN] Temperature out of plausible range: %.2f°C\n",
                      temp);
        return;
    }

    if (hum < 0.0 || hum > 100.0) {
        Serial.printf("[DHT22][WARN] Humidity out of plausible range: %.2f%%\n",
                      hum);
        return;
    }

    if (xSemaphoreTake(sensorDataMutex, pdMS_TO_TICKS(100)) == pdTRUE) {
        currentTemperature = temp;
        currentHumidity    = hum;
        xSemaphoreGive(sensorDataMutex);
    }

    // Clear DHT alert if sensor reading has recovered
    clearAlert(3);

    Serial.printf("[DHT22] Temp: %.2f°C  |  RH: %.2f%%"
                  "  |  Band: [%.2f%% MIN — %.2f%% MAX]\n",
                  temp, hum, HUMIDITY_MIN, HUMIDITY_MAX);
}

/**
 * @brief Reads EC sensor analog value and converts to dS/m.
 *
 * @return float Raw unfiltered EC in dS/m
 */
float readECRaw() {
    long adcSum = 0;
    for (int i = 0; i < 5; i++) {
        adcSum += analogRead(PIN_EC_SENSOR);
        delayMicroseconds(500);
    }

    float adcAvg  = (float)adcSum / 5.0;
    float voltage = (adcAvg / EC_ADC_RESOLUTION) * EC_ADC_REF_VOLTAGE;
    float ecRaw   = (voltage * EC_CONVERSION_COEFF) + EC_VOLTAGE_OFFSET;
    ecRaw         = constrain(ecRaw, 0.0, 20.0);

    Serial.printf("[EC][RAW] ADC: %.1f  |  Voltage: %.3fV  |  EC: %.3f dS/m"
                  "  |  Band: [%.1f – %.1f dS/m]\n",
                  adcAvg, voltage, ecRaw,
                  EC_LOWER_THRESHOLD, EC_UPPER_THRESHOLD);
    return ecRaw;
}

/**
 * @brief Reads water presence sensor on GPIO35.
 */
void readWaterSensor() {
    int rawValue = analogRead(PIN_WATER_SENSOR);
    if (xSemaphoreTake(sensorDataMutex, pdMS_TO_TICKS(100)) == pdTRUE) {
        currentWaterLevel = rawValue;
        xSemaphoreGive(sensorDataMutex);
    }
    Serial.printf("[WATER SENSOR] Raw ADC: %d\n", rawValue);
}

/**
 * @brief Reads float switch state on GPIO27.
 *        LOW  = water level physically low
 *        HIGH = water level adequate
 */
void readFloatSwitch() {
    bool isLow = (digitalRead(PIN_FLOAT_SWITCH) == LOW);
    if (xSemaphoreTake(sensorDataMutex, pdMS_TO_TICKS(100)) == pdTRUE) {
        floatSwitchLow = isLow;
        xSemaphoreGive(sensorDataMutex);
    }
    Serial.printf("[FLOAT SWITCH] %s\n",
                  isLow ? "LOW — Reservoir needs water" : "OK");
}

/**
 * @brief Reads DS3231 RTC timestamp.
 *
 * ALERT INTEGRATION:
 *   - Sets ALERT priority 3 if RTC has lost power
 *   - Adjusts RTC to compile time as fallback
 */
void readRTC() {

    // -----------------------------------------------------------------------
    // ALERT: RTC Lost Power
    // Trigger: rtc.lostPower() returns true
    // Action:  Set compile-time fallback, alert user
    // -----------------------------------------------------------------------
    if (rtc.lostPower()) {
        Serial.println("[RTC][WARN] RTC lost power — time may be incorrect!");
        Serial.println("[RTC][WARN] Grow light schedule may be affected!");

        // Set ALERT priority 3
        setAlert("ALERT: RTC Lost Power", 3);

        // Set fallback time to compile time
        rtc.adjust(DateTime(F(__DATE__), F(__TIME__)));
        Serial.println("[RTC] Fallback: time set to compile time.");
    }

    currentDateTime = rtc.now();
    snprintf(rtcTimeString, sizeof(rtcTimeString),
             "%02d:%02d:%02d %02d/%02d/%02d",
             currentDateTime.hour(), currentDateTime.minute(),
             currentDateTime.second(), currentDateTime.day(),
             currentDateTime.month(), currentDateTime.year() % 100);

    Serial.printf("[RTC] %s\n", rtcTimeString);
}

/**
 * @brief Calls all sensor read functions in sequence.
 */
void readAllSensors() {
    Serial.println("[SENSOR] ---- Reading All Sensors ----");
    readDHT22();
    float ecRaw = readECRaw();
    updateECMovingAverage(ecRaw);
    readWaterSensor();
    readFloatSwitch();
    readRTC();
    Serial.println("[SENSOR] ---- Complete ----");
}


/* ============================================================================
 * SECTION 5: EC FILTERING FUNCTION (Moving Average)
 * ============================================================================
 */

/**
 * @brief Updates circular moving average buffer with new EC sample.
 *        Window: 10 samples × 2 seconds = 20-second smoothing window.
 *
 * @param newSample  New raw EC value in dS/m
 */
void updateECMovingAverage(float newSample) {
    ecSampleBuffer[ecSampleIndex] = newSample;
    ecSampleIndex = (ecSampleIndex + 1) % EC_SAMPLE_COUNT;
    if (ecSampleIndex == 0) ecBufferFilled = true;

    int   count = ecBufferFilled ? EC_SAMPLE_COUNT : ecSampleIndex;
    float sum   = 0.0;
    for (int i = 0; i < count; i++) sum += ecSampleBuffer[i];
    float filtered = (count > 0) ? (sum / count) : newSample;

    if (xSemaphoreTake(sensorDataMutex, pdMS_TO_TICKS(100)) == pdTRUE) {
        currentEC = filtered;
        xSemaphoreGive(sensorDataMutex);
    }

    String ecZone;
    if      (filtered < EC_LOWER_THRESHOLD) ecZone = "LOW  → Dosing needed";
    else if (filtered > EC_UPPER_THRESHOLD) ecZone = "HIGH → Dilution needed";
    else                                    ecZone = "OK   → In range";

    Serial.printf("[EC][FILTER] Samples: %d  |  Filtered: %.3f dS/m  |  %s\n",
                  count, filtered, ecZone.c_str());
}


/* ============================================================================
 * SECTION 6: RTC LIGHT SCHEDULER
 * ============================================================================
 */

/**
 * @brief Controls grow lights via DS3231 RTC schedule.
 *        ON at 18:00 — OFF at 06:00. Handles overnight wrap-around.
 */
void controlGrowLights() {
    int nowMin = currentDateTime.hour() * 60 + currentDateTime.minute();
    int onMin  = LIGHTS_ON_HOUR  * 60 + LIGHTS_ON_MIN;
    int offMin = LIGHTS_OFF_HOUR * 60 + LIGHTS_OFF_MIN;

    bool shouldBeOn = (onMin > offMin)
                      ? (nowMin >= onMin || nowMin < offMin)
                      : (nowMin >= onMin && nowMin < offMin);

    if (shouldBeOn && !stateLights) {
        digitalWrite(PIN_RELAY_LIGHTS, RELAY_ON);
        stateLights = true;
        Serial.printf("[LIGHTS] → ON  | %s\n", rtcTimeString);

    } else if (!shouldBeOn && stateLights) {
        digitalWrite(PIN_RELAY_LIGHTS, RELAY_OFF);
        stateLights = false;
        Serial.printf("[LIGHTS] → OFF | %s\n", rtcTimeString);
    }
}


/* ============================================================================
 * SECTION 7: CIRCULATION PUMP TIMER LOGIC
 * ============================================================================
 */

/**
 * @brief Non-blocking NFT pump state machine — 15 min ON / 15 min OFF.
 *
 * ALERT INTEGRATION:
 *   - Sets ALERT priority 3 if pump exceeds 16-minute max runtime
 *   - Interlock: will not restart while refill pump is active
 */
void controlNFTPump() {
    unsigned long now = millis();

    // -----------------------------------------------------------------------
    // ALERT: NFT Pump Timeout
    // Trigger: Pump ON longer than NFT_PUMP_MAX_ON_MS (16 minutes)
    // Action:  Force pump OFF, set alert
    // -----------------------------------------------------------------------
    if (stateNFTPump && (now - nftPumpStartTime >= NFT_PUMP_MAX_ON_MS)) {
        digitalWrite(PIN_RELAY_NFT_PUMP, RELAY_OFF);
        stateNFTPump     = false;
        nftPumpState     = NFT_PUMP_OFF;
        nftPumpStartTime = now;

        // Set ALERT priority 3
        setAlert("ALERT: NFT Pump Timeout — Forced OFF", 3);

        Serial.println("[NFT PUMP][FAIL-SAFE] Max 16-min runtime exceeded!");
        Serial.println("[NFT PUMP][FAIL-SAFE] Check relay or pump hardware.");
        return;
    }

    switch (nftPumpState) {

        case NFT_PUMP_ON:
            if (now - nftPumpStartTime >= NFT_ON_DURATION_MS) {
                digitalWrite(PIN_RELAY_NFT_PUMP, RELAY_OFF);
                stateNFTPump     = false;
                nftPumpState     = NFT_PUMP_OFF;
                nftPumpStartTime = now;
                Serial.println("[NFT PUMP] → OFF | 15-min ON cycle complete.");
            }
            break;

        case NFT_PUMP_OFF:
            if (now - nftPumpStartTime >= NFT_OFF_DURATION_MS) {
                if (!stateRefillPump) {
                    digitalWrite(PIN_RELAY_NFT_PUMP, RELAY_ON);
                    stateNFTPump     = true;
                    nftPumpState     = NFT_PUMP_ON;
                    nftPumpStartTime = now;
                    Serial.println("[NFT PUMP] → ON  | 15-min OFF cycle complete.");
                } else {
                    Serial.println("[NFT PUMP] Delayed — refill pump active.");
                }
            }
            break;
    }
}


/* ============================================================================
 * SECTION 8: FLOAT SWITCH REFILL LOGIC
 * ============================================================================
 */

/**
 * @brief Controls refill pump based on PHYSICAL water level (float switch).
 *        Runs independently of EC-based refill logic in Section 9.
 *
 * ALERT INTEGRATION:
 *   - Sets WARN priority 2 when float switch detects low water
 *   - Sets ALERT priority 3 if pump exceeds 5-minute max runtime
 *   - Clears WARN priority 2 when water level is restored
 */
void controlFloatSwitchRefill() {
    unsigned long now = millis();

    // -----------------------------------------------------------------------
    // ALERT: Refill Pump Timeout (Float Switch Source)
    // Trigger: Pump ON longer than REFILL_PUMP_MAX_ON_MS (5 minutes)
    // Action:  Force pump OFF — water supply may be empty
    // -----------------------------------------------------------------------
    if (stateRefillPump && (now - refillPumpStartTime >= REFILL_PUMP_MAX_ON_MS)) {
        digitalWrite(PIN_RELAY_REFILL, RELAY_OFF);
        stateRefillPump = false;

        // Set ALERT priority 3
        setAlert("ALERT: Refill Pump Timeout — Check Water Supply!", 3);

        Serial.println("[REFILL PUMP][FAIL-SAFE] Max 5-min runtime exceeded!");
        Serial.println("[REFILL PUMP][FAIL-SAFE] Water supply may be empty.");
        return;
    }

    if (floatSwitchLow && !stateRefillPump) {
        // -----------------------------------------------------------------------
        // WARN: Low Water Level — Refilling
        // Trigger: Float switch reads LOW
        // Action:  Start refill pump, set WARN
        // -----------------------------------------------------------------------
        digitalWrite(PIN_RELAY_REFILL, RELAY_ON);
        stateRefillPump     = true;
        refillPumpStartTime = now;

        // Set WARN priority 2
        setAlert("WARN: Low Water Level — Refilling", 2);

        Serial.println("[REFILL PUMP] → ON  | Float switch LOW — physical refill");

    } else if (!floatSwitchLow && stateRefillPump) {
        // Water restored — only stop pump if EC also not requesting dilution
        if (currentEC <= EC_UPPER_THRESHOLD) {
            digitalWrite(PIN_RELAY_REFILL, RELAY_OFF);
            stateRefillPump = false;

            // Clear WARN priority 2 — condition resolved
            clearAlert(2);

            Serial.println("[REFILL PUMP] → OFF | Float OK, EC in range.");
        }
    }
}


/* ============================================================================
 * SECTION 9: NUTRIENT & EC CONTROL LOGIC
 * ============================================================================
 */

/**
 * @brief Controls dosing pump (EC low) and refill pump (EC high).
 *
 * ALERT INTEGRATION:
 *   - Sets ALERT priority 3 if dosing pump exceeds 30-second max runtime
 *   - Sets ALERT priority 3 if refill pump exceeds 5-minute max runtime
 *   - Sets WARN priority 2 when EC is high and dilution starts
 *   - Clears WARN priority 2 when EC returns to normal range
 */
void controlNutrientEC() {
    unsigned long now = millis();

    // Compute hysteresis thresholds
    float ecLowerActivate   = EC_LOWER_THRESHOLD - EC_HYSTERESIS;  // 1.15 dS/m
    float ecLowerDeactivate = EC_LOWER_THRESHOLD + EC_HYSTERESIS;  // 1.25 dS/m
    float ecUpperActivate   = EC_UPPER_THRESHOLD + EC_HYSTERESIS;  // 2.05 dS/m
    float ecUpperDeactivate = EC_UPPER_THRESHOLD - EC_HYSTERESIS;  // 1.95 dS/m

    // -----------------------------------------------------------------------
    // DOSING PUMP — EC too LOW → add nutrient concentrate
    // -----------------------------------------------------------------------

    // -----------------------------------------------------------------------
    // ALERT: Dosing Pump Timeout
    // Trigger: Pump ON longer than DOSING_PUMP_MAX_ON_MS (30 seconds)
    // Action:  Force pump OFF — EC not recovering, probe may be faulty
    // -----------------------------------------------------------------------
    if (stateDosingPump && (now - dosingPumpStartTime >= DOSING_PUMP_MAX_ON_MS)) {
        digitalWrite(PIN_RELAY_DOSING, RELAY_OFF);
        stateDosingPump = false;

        // Set ALERT priority 3
        setAlert("ALERT: Dosing Pump Timeout — Check EC Probe!", 3);

        Serial.println("[DOSING PUMP][FAIL-SAFE] Max 30s runtime exceeded!");
        Serial.println("[DOSING PUMP][FAIL-SAFE] EC not recovering — probe fault?");
    }

    if (!stateDosingPump) {
        if (currentEC < ecLowerActivate &&
            currentEC > 0.01           &&
            !floatSwitchLow            &&
            !stateRefillPump) {

            digitalWrite(PIN_RELAY_DOSING, RELAY_ON);
            stateDosingPump     = true;
            dosingPumpStartTime = now;
            Serial.printf("[DOSING PUMP] → ON  | EC=%.3f < %.3f dS/m"
                          " — Adding nutrient concentrate\n",
                          currentEC, ecLowerActivate);
        }

    } else {
        if (currentEC >= ecLowerDeactivate) {
            digitalWrite(PIN_RELAY_DOSING, RELAY_OFF);
            stateDosingPump = false;
            Serial.printf("[DOSING PUMP] → OFF | EC=%.3f ≥ %.3f dS/m"
                          " — Nutrient level restored\n",
                          currentEC, ecLowerDeactivate);
        }
    }

    // -----------------------------------------------------------------------
    // REFILL PUMP (EC Dilution) — EC too HIGH → add plain water
    // -----------------------------------------------------------------------

    // -----------------------------------------------------------------------
    // ALERT: Refill Pump Timeout (EC Dilution Source)
    // Trigger: Pump ON longer than REFILL_PUMP_MAX_ON_MS (5 minutes)
    // Action:  Force pump OFF — EC not dropping, sensor may be faulty
    // -----------------------------------------------------------------------
    if (stateRefillPump && (now - refillPumpStartTime >= REFILL_PUMP_MAX_ON_MS)) {
        digitalWrite(PIN_RELAY_REFILL, RELAY_OFF);
        stateRefillPump = false;

        // Set ALERT priority 3
        setAlert("ALERT: Refill Pump Timeout — Sensor Check Required!", 3);

        Serial.println("[REFILL PUMP][FAIL-SAFE] Max 5-min runtime exceeded!");
        Serial.println("[REFILL PUMP][FAIL-SAFE] EC not dropping — sensor fault?");
        return;
    }

    if (!stateRefillPump) {
        // -----------------------------------------------------------------------
        // WARN: EC High — Diluting with plain water
        // Trigger: EC rises above 2.05 dS/m (upper + hysteresis)
        // Action:  Start refill pump, set WARN
        // -----------------------------------------------------------------------
        if (currentEC > ecUpperActivate && !stateDosingPump) {
            digitalWrite(PIN_RELAY_REFILL, RELAY_ON);
            stateRefillPump     = true;
            refillPumpStartTime = now;

            // Set WARN priority 2
            setAlert("WARN: EC High — Diluting with plain water", 2);

            Serial.printf("[REFILL PUMP] → ON  | EC=%.3f > %.3f dS/m"
                          " — Adding plain water to dilute\n",
                          currentEC, ecUpperActivate);
        }

    } else {
        if (currentEC <= ecUpperDeactivate && !floatSwitchLow) {
            digitalWrite(PIN_RELAY_REFILL, RELAY_OFF);
            stateRefillPump = false;

            // Clear WARN priority 2 — EC restored to range
            clearAlert(2);

            Serial.printf("[REFILL PUMP] → OFF | EC=%.3f ≤ %.3f dS/m"
                          " — EC restored to range\n",
                          currentEC, ecUpperDeactivate);
        }
    }
}


/* ============================================================================
 * SECTION 10: HUMIDITY ACTUATOR CONTROL
 * ============================================================================
 */

/**
 * @brief Controls mister (RH low) and exhaust fan (RH high).
 *
 * ALERT INTEGRATION:
 *   - Sets ALERT priority 3 if mister exceeds 2-minute max runtime
 *   - Sets ALERT priority 3 if exhaust exceeds 10-minute max runtime
 *   - Sets WARN priority 2 when mister activates (RH too low)
 *   - Sets WARN priority 2 when exhaust activates (RH too high)
 *   - Clears WARN priority 2 when RH returns to normal range
 *   - Mutual exclusion: mister and exhaust cannot run simultaneously
 */
void controlHumidity() {
    unsigned long now = millis();

    // Compute hysteresis thresholds
    float rhMisterActivate    = HUMIDITY_MIN - HUMIDITY_HYSTERESIS;  // 67.01%
    float rhMisterDeactivate  = HUMIDITY_MIN + HUMIDITY_HYSTERESIS;  // 67.51%
    float rhExhaustActivate   = HUMIDITY_MAX + HUMIDITY_HYSTERESIS;  // 69.97%
    float rhExhaustDeactivate = HUMIDITY_MAX - HUMIDITY_HYSTERESIS;  // 69.47%

    // -----------------------------------------------------------------------
    // MISTER — RH too LOW
    // -----------------------------------------------------------------------

    // -----------------------------------------------------------------------
    // ALERT: Mister Timeout
    // Trigger: Mister ON longer than MISTER_MAX_ON_MS (2 minutes)
    // Action:  Force mister OFF — RH not recovering, sensor may be faulty
    // -----------------------------------------------------------------------
    if (stateMister && (now - misterStartTime >= MISTER_MAX_ON_MS)) {
        digitalWrite(PIN_RELAY_MISTER, RELAY_OFF);
        stateMister = false;

        // Set ALERT priority 3
        setAlert("ALERT: Mister Timeout — Check RH Sensor!", 3);

        Serial.println("[MISTER][FAIL-SAFE] Max 2-min runtime exceeded!");
        Serial.println("[MISTER][FAIL-SAFE] RH not recovering — sensor fault?");
    }

    if (!stateMister) {
        // -----------------------------------------------------------------------
        // WARN: RH Low — Misting to raise humidity
        // Trigger: RH drops below 67.01% (MIN - hysteresis)
        // Action:  Start mister, set WARN
        // -----------------------------------------------------------------------
        if (currentHumidity < rhMisterActivate && !stateExhaust) {
            digitalWrite(PIN_RELAY_MISTER, RELAY_ON);
            stateMister     = true;
            misterStartTime = now;

            // Set WARN priority 2
            setAlert("WARN: RH Low — Misting to raise humidity", 2);

            Serial.printf("[MISTER] → ON  | RH=%.2f%% < %.2f%%"
                          " — Raising humidity (MIN: %.2f%%)\n",
                          currentHumidity, rhMisterActivate, HUMIDITY_MIN);
        }

    } else {
        if (currentHumidity >= rhMisterDeactivate) {
            digitalWrite(PIN_RELAY_MISTER, RELAY_OFF);
            stateMister = false;

            // Clear WARN priority 2 — humidity restored above MIN
            clearAlert(2);

            Serial.printf("[MISTER] → OFF | RH=%.2f%% ≥ %.2f%%"
                          " — Humidity restored above MIN\n",
                          currentHumidity, rhMisterDeactivate);
        }
    }

    // -----------------------------------------------------------------------
    // EXHAUST FAN — RH too HIGH
    // -----------------------------------------------------------------------

    // -----------------------------------------------------------------------
    // ALERT: Exhaust Timeout
    // Trigger: Exhaust ON longer than EXHAUST_MAX_ON_MS (10 minutes)
    // Action:  Force exhaust OFF — RH not dropping, sensor may be faulty
    // -----------------------------------------------------------------------
    if (stateExhaust && (now - exhaustStartTime >= EXHAUST_MAX_ON_MS)) {
        digitalWrite(PIN_RELAY_EXHAUST, RELAY_OFF);
        stateExhaust = false;

        // Set ALERT priority 3
        setAlert("ALERT: Exhaust Timeout — Check RH Sensor!", 3);

        Serial.println("[EXHAUST][FAIL-SAFE] Max 10-min runtime exceeded!");
        Serial.println("[EXHAUST][FAIL-SAFE] RH not dropping — sensor fault?");
    }

    if (!stateExhaust) {
        // -----------------------------------------------------------------------
        // WARN: RH High — Exhaust fan to lower humidity
        // Trigger: RH rises above 69.97% (MAX + hysteresis)
        // Action:  Start exhaust fan, set WARN
        // -----------------------------------------------------------------------
        if (currentHumidity > rhExhaustActivate && !stateMister) {
            digitalWrite(PIN_RELAY_EXHAUST, RELAY_ON);
            stateExhaust     = true;
            exhaustStartTime = now;

            // Set WARN priority 2
            setAlert("WARN: RH High — Exhaust fan to lower humidity", 2);

            Serial.printf("[EXHAUST] → ON  | RH=%.2f%% > %.2f%%"
                          " — Lowering humidity (MAX: %.2f%%)\n",
                          currentHumidity, rhExhaustActivate, HUMIDITY_MAX);
        }

    } else {
        if (currentHumidity <= rhExhaustDeactivate) {
            digitalWrite(PIN_RELAY_EXHAUST, RELAY_OFF);
            stateExhaust = false;

            // Clear WARN priority 2 — humidity restored below MAX
            clearAlert(2);

            Serial.printf("[EXHAUST] → OFF | RH=%.2f%% ≤ %.2f%%"
                          " — Humidity restored below MAX\n",
                          currentHumidity, rhExhaustDeactivate);
        }
    }

    // -----------------------------------------------------------------------
    // MUTUAL EXCLUSION SAFETY CHECK
    // If both somehow activated simultaneously — exhaust takes priority
    // -----------------------------------------------------------------------
    if (stateMister && stateExhaust) {
        digitalWrite(PIN_RELAY_MISTER, RELAY_OFF);
        stateMister = false;
        Serial.println("[HUMIDITY][INTERLOCK] Conflict — Mister OFF, Exhaust priority.");
    }
}


/* ============================================================================
 * SECTION 11: BLYNK UPDATE FUNCTION
 * ============================================================================
 */

/**
 * @brief Pushes all sensor readings and actuator states to Blynk dashboard.
 *        V10 sends the current systemAlert string — updated by setAlert().
 */
void updateBlynk() {
    if (!Blynk.connected()) {
        Serial.println("[BLYNK] Not connected — skipping update");
        return;
    }

    // Sensor readings
    Blynk.virtualWrite(V0, currentTemperature);
    Blynk.virtualWrite(V1, currentHumidity);
    Blynk.virtualWrite(V2, currentEC);
    Blynk.virtualWrite(V3, currentWaterLevel);
    Blynk.virtualWrite(V4, floatSwitchLow ? 0 : 1);

    // Actuator states
    Blynk.virtualWrite(V5,  stateNFTPump    ? 1 : 0);
    Blynk.virtualWrite(V6,  stateDosingPump ? 1 : 0);
    Blynk.virtualWrite(V7,  stateRefillPump ? 1 : 0);
    Blynk.virtualWrite(V8,  stateLights     ? 1 : 0);
    Blynk.virtualWrite(V15, stateMister     ? 1 : 0);
    Blynk.virtualWrite(V16, stateExhaust    ? 1 : 0);

    // System info
    Blynk.virtualWrite(V9,  String(rtcTimeString));
    Blynk.virtualWrite(V10, systemAlert);        // ← Sends current alert to dashboard

    // Active thresholds
    Blynk.virtualWrite(V11, EC_LOWER_THRESHOLD);
    Blynk.virtualWrite(V12, EC_UPPER_THRESHOLD);
    Blynk.virtualWrite(V13, HUMIDITY_MIN);
    Blynk.virtualWrite(V14, HUMIDITY_MAX);

    Serial.printf("[BLYNK] V10 Alert: %s (Priority: %d)\n",
                  systemAlert.c_str(), currentAlertPriority);
}

// ---------------------------------------------------------------------------
// BLYNK WRITE CALLBACKS
// ---------------------------------------------------------------------------

BLYNK_WRITE(V11) {
    float val = param.asFloat();
    if (val > 0.1 && val < (EC_UPPER_THRESHOLD - 0.1)) {
        EC_LOWER_THRESHOLD = val;
        preferences.begin("hydro-cfg", false);
        preferences.putFloat("ec_lower", EC_LOWER_THRESHOLD);
        preferences.end();
        Serial.printf("[BLYNK][NVS] EC Lower → %.3f dS/m\n", EC_LOWER_THRESHOLD);
    }
}

BLYNK_WRITE(V12) {
    float val = param.asFloat();
    if (val > (EC_LOWER_THRESHOLD + 0.1) && val <= 10.0) {
        EC_UPPER_THRESHOLD = val;
        preferences.begin("hydro-cfg", false);
        preferences.putFloat("ec_upper", EC_UPPER_THRESHOLD);
        preferences.end();
        Serial.printf("[BLYNK][NVS] EC Upper → %.3f dS/m\n", EC_UPPER_THRESHOLD);
    }
}

BLYNK_WRITE(V13) {
    float val = param.asFloat();
    if (val >= 40.0 && val < (HUMIDITY_MAX - 0.5)) {
        HUMIDITY_MIN    = val;
        HUMIDITY_TARGET = (HUMIDITY_MIN + HUMIDITY_MAX) / 2.0;
        preferences.begin("hydro-cfg", false);
        preferences.putFloat("hum_min",    HUMIDITY_MIN);
        preferences.putFloat("hum_target", HUMIDITY_TARGET);
        preferences.end();
        Serial.printf("[BLYNK][NVS] Humidity MIN → %.2f%%  Target: %.2f%%\n",
                      HUMIDITY_MIN, HUMIDITY_TARGET);
    }
}

BLYNK_WRITE(V14) {
    float val = param.asFloat();
    if (val > (HUMIDITY_MIN + 0.5) && val <= 95.0) {
        HUMIDITY_MAX    = val;
        HUMIDITY_TARGET = (HUMIDITY_MIN + HUMIDITY_MAX) / 2.0;
        preferences.begin("hydro-cfg", false);
        preferences.putFloat("hum_max",    HUMIDITY_MAX);
        preferences.putFloat("hum_target", HUMIDITY_TARGET);
        preferences.end();
        Serial.printf("[BLYNK][NVS] Humidity MAX → %.2f%%  Target: %.2f%%\n",
                      HUMIDITY_MAX, HUMIDITY_TARGET);
    }
}


/* ============================================================================
 * SECTION 12: FAIL-SAFE SAFETY CHECK
 * ============================================================================
 */

/**
 * @brief Global fail-safe checker — runs first in every control cycle.
 *
 * ALERT INTEGRATION (all alerts set here):
 *   - EMERGENCY priority 4: Temperature out of safe range
 *   - ALERT priority 3:     EC probe disconnected
 *   - ALERT priority 3:     EC over-limit with dosing active
 *   - WARN priority 2:      Dosing with low water interlock
 *   - No alert set:         Mister+Exhaust conflict (handled internally)
 */
void systemFailSafeCheck() {
    bool emergencyStop = false;

    // -----------------------------------------------------------------------
    // EMERGENCY: Temperature Critical
    // Trigger: Temp < 0°C or > 45°C
    // Action:  Set EMERGENCY priority 4, force all actuators OFF, halt system
    // -----------------------------------------------------------------------
    if (currentTemperature < 0.0 || currentTemperature > 45.0) {
        Serial.printf("[FAIL-SAFE][EMERGENCY] Temp=%.2f°C — Critical!\n",
                      currentTemperature);
        Serial.println("[FAIL-SAFE] ALL actuators shutting down NOW!");

        // Set EMERGENCY priority 4 — HIGHEST — cannot be overwritten
        setAlert("EMERGENCY: Temperature Critical!", 4);

        emergencyStop = true;
    }

    // -----------------------------------------------------------------------
    // ALERT: EC Probe Disconnected
    // Trigger: EC near zero after buffer is fully populated
    // Action:  Force dosing OFF, set ALERT priority 3
    // -----------------------------------------------------------------------
    if (currentEC < 0.01 && ecBufferFilled) {
        Serial.println("[FAIL-SAFE][ALERT] EC near zero — probe disconnected?");

        // Set ALERT priority 3
        setAlert("ALERT: EC Probe Disconnected — Dosing Halted", 3);

        if (stateDosingPump) {
            digitalWrite(PIN_RELAY_DOSING, RELAY_OFF);
            stateDosingPump = false;
            Serial.println("[FAIL-SAFE] Dosing pump forced OFF — EC fault.");
        }
    }

    // -----------------------------------------------------------------------
    // ALERT: EC Over-Limit — Dosing Forced OFF
    // Trigger: EC > upper threshold + 0.3 while dosing pump is active
    // Action:  Force dosing OFF immediately, set ALERT priority 3
    // -----------------------------------------------------------------------
    if (stateDosingPump && currentEC > (EC_UPPER_THRESHOLD + 0.3)) {
        Serial.printf("[FAIL-SAFE][ALERT] EC=%.3f — Over-limit with dosing ON!\n",
                      currentEC);

        // Force dosing pump OFF
        digitalWrite(PIN_RELAY_DOSING, RELAY_OFF);
        stateDosingPump = false;

        // Set ALERT priority 3
        setAlert("ALERT: EC Over-Limit — Dosing Forced OFF", 3);

        Serial.println("[FAIL-SAFE] Dosing forced OFF — EC overdose prevented.");
    }

    // -----------------------------------------------------------------------
    // WARN: Dosing stopped — reservoir too low
    // Trigger: Dosing pump ON while float switch reads LOW
    // Action:  Force dosing OFF — cannot dose into empty reservoir
    // -----------------------------------------------------------------------
    if (stateDosingPump && floatSwitchLow) {
        Serial.println("[FAIL-SAFE][WARN] Dosing + low water — interlock!");

        // Force dosing pump OFF
        digitalWrite(PIN_RELAY_DOSING, RELAY_OFF);
        stateDosingPump = false;

        // Set WARN priority 2
        setAlert("WARN: Dosing stopped — reservoir too low", 2);

        Serial.println("[FAIL-SAFE] Dosing OFF — low water interlock triggered.");
    }

    // -----------------------------------------------------------------------
    // INTERLOCK: Mister + Exhaust simultaneously ON
    // Trigger: Both humidity actuators active at same time (sensor glitch)
    // Action:  Force mister OFF — exhaust takes priority
    // No alert set — handled silently, logged to Serial only
    // -----------------------------------------------------------------------
    if (stateMister && stateExhaust) {
        digitalWrite(PIN_RELAY_MISTER, RELAY_OFF);
        stateMister = false;
        Serial.println("[FAIL-SAFE] Mister + Exhaust conflict — Mister forced OFF.");
    }

    // -----------------------------------------------------------------------
    // EMERGENCY STOP — All actuators OFF — System halted
    // -----------------------------------------------------------------------
    if (emergencyStop) {
        digitalWrite(PIN_RELAY_DOSING,   RELAY_OFF);
        digitalWrite(PIN_RELAY_NFT_PUMP, RELAY_OFF);
        digitalWrite(PIN_RELAY_REFILL,   RELAY_OFF);
        digitalWrite(PIN_RELAY_LIGHTS,   RELAY_OFF);
        digitalWrite(PIN_RELAY_MISTER,   RELAY_OFF);
        digitalWrite(PIN_RELAY_EXHAUST,  RELAY_OFF);

        stateDosingPump = stateNFTPump  = stateRefillPump = false;
        stateLights     = stateMister   = stateExhaust    = false;

        // Push emergency alert to Blynk immediately before halting
        if (Blynk.connected()) {
            Blynk.virtualWrite(V10, systemAlert);
        }

        Serial.println("[EMERGENCY] All actuators OFF.");
        Serial.println("[EMERGENCY] System halted — manual reset required!");
        vTaskSuspend(NULL);  // Suspend this task — requires physical reset
    }
}

/**
 * @brief Prints full system status to Serial Monitor.
 */
void printDebugSummary() {
    Serial.println("=============================================================");
    Serial.printf(" Time        : %s\n",     rtcTimeString);
    Serial.printf(" Temperature : %.2f°C\n", currentTemperature);
    Serial.printf(" Humidity    : %.2f%%"
                  "  [MIN:%.2f%%  TGT:%.2f%%  MAX:%.2f%%]  → %s\n",
                  currentHumidity, HUMIDITY_MIN, HUMIDITY_TARGET, HUMIDITY_MAX,
                  (currentHumidity < HUMIDITY_MIN) ? "LOW — Mister ON"  :
                  (currentHumidity > HUMIDITY_MAX) ? "HIGH — Exhaust ON" : "IN RANGE");
    Serial.printf(" EC (filt.)  : %.3f dS/m"
                  "  [LOW:%.1f  HIGH:%.1f]  → %s\n",
                  currentEC, EC_LOWER_THRESHOLD, EC_UPPER_THRESHOLD,
                  (currentEC < EC_LOWER_THRESHOLD) ? "LOW — Dosing ON"   :
                  (currentEC > EC_UPPER_THRESHOLD)  ? "HIGH — Diluting ON" : "IN RANGE");
    Serial.printf(" Water ADC   : %d\n", currentWaterLevel);
    Serial.printf(" Float SW    : %s\n",
                  floatSwitchLow ? "LOW (Refill)" : "OK");
    Serial.println(" --- ACTUATORS ---");
    Serial.printf(" NFT Pump    : %s\n", stateNFTPump    ? "ON"                   : "OFF");
    Serial.printf(" Dosing Pump : %s\n", stateDosingPump ? "ON — Adding Nutrient"  : "OFF");
    Serial.printf(" Refill Pump : %s\n", stateRefillPump ? "ON — Adding Water"     : "OFF");
    Serial.printf(" Grow Lights : %s\n", stateLights     ? "ON"                   : "OFF");
    Serial.printf(" Mister      : %s\n", stateMister     ? "ON — Raising RH"      : "OFF");
    Serial.printf(" Exhaust Fan : %s\n", stateExhaust    ? "ON — Lowering RH"     : "OFF");
    Serial.println(" --- ALERT ---");
    Serial.printf(" Priority    : %d\n", currentAlertPriority);
    Serial.printf(" Message     : %s\n", systemAlert.c_str());
    Serial.println("=============================================================");
}


/* ============================================================================
 * FREERTOS TASKS
 * ============================================================================
 */

/**
 * @brief Sensor Task — Core 1 — reads all sensors every 2 seconds.
 */
void sensorTask(void* pvParameters) {
    Serial.println("[RTOS] Sensor Task → Core 1");
    TickType_t xLastWakeTime = xTaskGetTickCount();

    while (true) {
        readAllSensors();

        unsigned long now = millis();
        if (now - lastDebugPrintTime >= DEBUG_PRINT_INTERVAL_MS) {
            lastDebugPrintTime = now;
            printDebugSummary();
        }

        vTaskDelayUntil(&xLastWakeTime, pdMS_TO_TICKS(SENSOR_READ_INTERVAL_MS));
    }
}

/**
 * @brief Control Task — Core 0 — runs all control logic every 500ms.
 */
void controlTask(void* pvParameters) {
    Serial.println("[RTOS] Control Task → Core 0");
    TickType_t xLastWakeTime = xTaskGetTickCount();

    while (true) {
        unsigned long now = millis();

        systemFailSafeCheck();       // Always first — highest priority checks
        controlGrowLights();         // RTC photoperiod schedule
        controlNFTPump();            // 15 min ON / 15 min OFF timer
        controlFloatSwitchRefill();  // Physical water level
        controlNutrientEC();         // EC dosing + dilution
        controlHumidity();           // RH misting + exhaust

        Blynk.run();

        if (now - lastBlynkUpdateTime >= BLYNK_UPDATE_INTERVAL_MS) {
            lastBlynkUpdateTime = now;
            updateBlynk();
        }

        vTaskDelayUntil(&xLastWakeTime, pdMS_TO_TICKS(500));
    }
}


/* ============================================================================
 * SETUP()
 * ============================================================================
 */
void setup() {
    Serial.begin(115200);
    delay(500);
    Serial.println("\n=============================================================");
    Serial.println("  ESP32 Hydroponic System v4.0.0");
    Serial.println("  Full Alert System — Priority-Based V10 Notifications");
    Serial.println("  Humidity: Mister (RH<67.26%) | Exhaust (RH>69.72%)");
    Serial.println("  EC: Dosing (EC<1.2) | Dilution Refill (EC>2.0 dS/m)");
    Serial.println("=============================================================");

    // All relay pins → safe OFF state
    int relayPins[] = {PIN_RELAY_DOSING, PIN_RELAY_NFT_PUMP,
                       PIN_RELAY_REFILL, PIN_RELAY_LIGHTS,
                       PIN_RELAY_MISTER, PIN_RELAY_EXHAUST};
    for (int i = 0; i < 6; i++) {
        pinMode(relayPins[i], OUTPUT);
        digitalWrite(relayPins[i], RELAY_OFF);
    }
    Serial.println("[INIT] All 6 relays → SAFE OFF state.");

    // Sensor GPIO
    pinMode(PIN_FLOAT_SWITCH, INPUT_PULLUP);
    analogReadResolution(12);
    analogSetAttenuation(ADC_11db);
    Serial.println("[INIT] Sensor GPIO configured.");

    // DHT22
    dht.begin();
    Serial.println("[INIT] DHT22 initialized on GPIO 4.");

    // DS3231 RTC
    Wire.begin(21, 22);
    if (!rtc.begin()) {
        Serial.println("[INIT][ERROR] DS3231 not found!");
        setAlert("ALERT: RTC Not Found", 3);
    } else {
        if (rtc.lostPower()) {
            rtc.adjust(DateTime(F(__DATE__), F(__TIME__)));
            Serial.println("[INIT][WARN] RTC set to compile time.");
        }
        currentDateTime = rtc.now();
        Serial.printf("[INIT] RTC: %02d:%02d:%02d\n",
                      currentDateTime.hour(),
                      currentDateTime.minute(),
                      currentDateTime.second());
    }

    // NVS — Load saved thresholds
    preferences.begin("hydro-cfg", true);
    float s_ecLow  = preferences.getFloat("ec_lower", EC_LOWER_THRESHOLD);
    float s_ecHigh = preferences.getFloat("ec_upper", EC_UPPER_THRESHOLD);
    float s_humMin = preferences.getFloat("hum_min",  HUMIDITY_MIN);
    float s_humMax = preferences.getFloat("hum_max",  HUMIDITY_MAX);
    preferences.end();

    if (s_ecLow  > 0.1  && s_ecLow  < s_ecHigh)    EC_LOWER_THRESHOLD = s_ecLow;
    if (s_ecHigh > s_ecLow && s_ecHigh <= 10.0)     EC_UPPER_THRESHOLD = s_ecHigh;
    if (s_humMin >= 40.0 && s_humMin < s_humMax)    HUMIDITY_MIN       = s_humMin;
    if (s_humMax > s_humMin && s_humMax <= 95.0)    HUMIDITY_MAX       = s_humMax;
    HUMIDITY_TARGET = (HUMIDITY_MIN + HUMIDITY_MAX) / 2.0;

    Serial.printf("[NVS] EC: %.2f – %.2f dS/m  |"
                  "  RH: %.2f%% – %.2f%%  (TGT: %.2f%%)\n",
                  EC_LOWER_THRESHOLD, EC_UPPER_THRESHOLD,
                  HUMIDITY_MIN, HUMIDITY_MAX, HUMIDITY_TARGET);

    // EC filter pre-fill
    for (int i = 0; i < EC_SAMPLE_COUNT; i++) ecSampleBuffer[i] = 1.5;
    currentEC = 1.5;
    Serial.println("[INIT] EC filter → pre-filled at 1.5 dS/m.");

    // NFT pump initial state
    nftPumpState     = NFT_PUMP_OFF;
    nftPumpStartTime = millis();
    Serial.println("[INIT] NFT pump → initial OFF phase.");

    // Mutex
    sensorDataMutex = xSemaphoreCreateMutex();
    Serial.println(sensorDataMutex ? "[INIT] Mutex created."
                                   : "[INIT][ERROR] Mutex failed!");

    // WiFi + Blynk
    Serial.printf("[WIFI] Connecting to: %s\n", WIFI_SSID);
    Blynk.begin(BLYNK_AUTH_TOKEN, WIFI_SSID, WIFI_PASSWORD);
    unsigned long t = millis();
    while (!Blynk.connected() && (millis() - t < 15000)) {
        Serial.print(".");
        delay(500);
    }

    if (Blynk.connected()) {
        Serial.println("\n[WIFI] Blynk connected successfully!");
    } else {
        Serial.println("\n[WIFI][WARN] Blynk offline — running in local mode.");
        setAlert("WARN: Blynk Offline — Local Control Active", 2);
    }

    // FreeRTOS Tasks
    xTaskCreatePinnedToCore(sensorTask,  "SensorTask",  4096, NULL, 2,
                            &sensorTaskHandle,  1);
    xTaskCreatePinnedToCore(controlTask, "ControlTask", 8192, NULL, 1,
                            &controlTaskHandle, 0);

    Serial.println("[INIT] FreeRTOS tasks created.");
    Serial.println("[INIT] ✓ System fully initialized.");
    Serial.println("=============================================================");
    Serial.println("  ALERT PRIORITY SYSTEM:");
    Serial.println("  Priority 1 → SYSTEM OK");
    Serial.println("  Priority 2 → WARN  (automated response active)");
    Serial.println("  Priority 3 → ALERT (sensor/actuator fault)");
    Serial.println("  Priority 4 → EMERGENCY (full shutdown)");
    Serial.println("=============================================================");
    Serial.println("  CONTROL SUMMARY:");
    Serial.printf("  RH  < %.2f%%    → Mister ON\n",     HUMIDITY_MIN);
    Serial.printf("  RH  > %.2f%%    → Exhaust Fan ON\n", HUMIDITY_MAX);
    Serial.printf("  EC  < %.2f dS/m → Dosing Pump ON\n", EC_LOWER_THRESHOLD);
    Serial.printf("  EC  > %.2f dS/m → Refill Pump ON\n", EC_UPPER_THRESHOLD);
    Serial.println("  NFT Pump        → 15 min ON / 15 min OFF");
    Serial.println("  Grow Lights     → ON 18:00 / OFF 06:00");
    Serial.println("=============================================================\n");
}


/* ============================================================================
 * LOOP()
 * ============================================================================
 */
void loop() {
    vTaskDelay(pdMS_TO_TICKS(1000));
}