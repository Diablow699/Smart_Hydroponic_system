#define BLYNK_TEMPLATE_ID "TMPL6IkGktaE7"
#define BLYNK_TEMPLATE_NAME "Hydroponic"
#define BLYNK_AUTH_TOKEN      "zYQlrbS2K7Jp49GZbNJFqKjrvO9EtnCP"

#define BLYNK_PRINT Serial
#include <WiFi.h>
#include <BlynkSimpleEsp32.h>
#include "DHT.h"

char ssid[] = "Diablow";
char pass[] = "12345678";

#define DHTPIN  14
#define DHTTYPE DHT22

#define VPIN_TEMPERATURE  V0
#define VPIN_HUMIDITY     V1

DHT dht(DHTPIN, DHTTYPE);
BlynkTimer timer;

void readDHT() {
  float humidity = dht.readHumidity();
  float tempC    = dht.readTemperature();

  if (isnan(humidity) || isnan(tempC)) {
    Serial.println("⚠ Failed to read from DHT22! Check wiring.");
    return;
  }

  // Upload to Blynk
  Blynk.virtualWrite(VPIN_TEMPERATURE, tempC);
  Blynk.virtualWrite(VPIN_HUMIDITY, humidity);

  // Serial Monitor output
  Serial.println("=============================");
  Serial.print("Temperature : ");
  Serial.print(tempC);
  Serial.println(" °C");
  Serial.print("Humidity    : ");
  Serial.print(humidity);
  Serial.println(" %");
  Serial.println("=============================");
}

void setup() {
  Serial.begin(115200);
  dht.begin();
  delay(2000);
  Blynk.begin(BLYNK_AUTH_TOKEN, ssid, pass);
  timer.setInterval(2000L, readDHT);
  Serial.println("DHT22 + Blynk Ready!");
}

void loop() {
  Blynk.run();
  timer.run();
}